<?php 
session_start();
include('includes/config.php');
error_reporting(0);
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
<title>Agricultural Equipment Rental System | Equipment Listing</title>
<!--Bootstrap -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
<!--Custome Style -->
<link rel="stylesheet" href="assets/css/style.css" type="text/css">
<!--OWL Carousel slider-->
<link rel="stylesheet" href="assets/css/owl.carousel.css" type="text/css">
<link rel="stylesheet" href="assets/css/owl.transitions.css" type="text/css">
<!--slick-slider -->
<link href="assets/css/slick.css" rel="stylesheet">
<!--bootstrap-slider -->
<link href="assets/css/bootstrap-slider.min.css" rel="stylesheet">
<!--FontAwesome -->
<link href="assets/css/font-awesome.min.css" rel="stylesheet">

<!-- SWITCHER -->
<link rel="stylesheet" id="switcher-css" type="text/css" href="assets/switcher/css/switcher.css" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/red.css" title="red" media="all" data-default-color="true" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/orange.css" title="orange" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/blue.css" title="blue" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/pink.css" title="pink" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/green.css" title="green" media="all" />
<link rel="alternate stylesheet" type="text/css" href="assets/switcher/css/purple.css" title="purple" media="all" />

<!-- Favicon -->
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/favicon-icon/apple-touch-icon-144-precomposed.png">
<link rel="shortcut icon" href="assets/images/favicon-icon/favicon.png">
<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
</head>
<body>

<!-- Start Switcher -->
<?php include('includes/colorswitcher.php');?>
<!-- /Switcher -->  

<!--Header--> 
<?php include('includes/header.php');?>
<!-- /Header --> 

<section class="listing-page">
  <div class="container">
    <div class="row">

      <!-- Main Content -->
      <div class="col-md-9 col-md-push-3">
        <div class="result-sorting-wrapper">
          <div class="sorting-count">
<?php 
// --- Collect Filters ---
$searchdata = isset($_REQUEST['searchdata']) ? trim($_REQUEST['searchdata']) : "";
$type = isset($_REQUEST['type']) ? $_REQUEST['type'] : "";
$fuel = isset($_REQUEST['fuel']) ? $_REQUEST['fuel'] : "";

// --- Base Query ---
$sql = "SELECT tblequipments.*, tbltypes.BrandName, tbltypes.id as bid  
        FROM tblequipments 
        JOIN tbltypes ON tbltypes.id = tblequipments.VehiclesBrand 
        WHERE 1=1";

// --- Dynamic Conditions ---
$params = [];

if(!empty($searchdata)) {
    $sql .= " AND (tblequipments.VehiclesTitle LIKE :search 
              OR tblequipments.FuelType LIKE :search 
              OR tbltypes.BrandName LIKE :search 
              OR tblequipments.ModelYear LIKE :search)";
    $params[':search'] = "%$searchdata%";
}

if(!empty($type)) {
    $sql .= " AND tblequipments.VehiclesBrand = :type";
    $params[':type'] = $type;
}

if(!empty($fuel)) {
    $sql .= " AND tblequipments.FuelType = :fuel";
    $params[':fuel'] = $fuel;
}

$query = $dbh->prepare($sql);
foreach($params as $key=>$val){
    $query->bindValue($key,$val);
}
$query->execute();
$results = $query->fetchAll(PDO::FETCH_OBJ);
$cnt = $query->rowCount();
?>
<p><span><?php echo htmlentities($cnt);?> Search Result<?php if(!empty($searchdata)) echo ' for keyword "'.htmlentities($searchdata).'"';?></span></p>
</div>
</div>

<?php 
if($cnt > 0) {
foreach($results as $result) {  ?>
  <div class="product-listing-m gray-bg">
    <div class="product-listing-img">
      <img src="admin/img/vehicleimages/<?php echo htmlentities($result->Vimage1);?>" class="img-responsive" alt="Image" /> 
    </div>
    <div class="product-listing-content">
      <h5><a href="vehical-details.php?vhid=<?php echo htmlentities($result->id);?>">
        <?php echo htmlentities($result->BrandName);?> , <?php echo htmlentities($result->VehiclesTitle);?>
      </a></h5>
      <p class="list-price">$<?php echo htmlentities($result->PricePerDay);?> Per Day</p>
      <ul>
        <li><i class="fa fa-user" aria-hidden="true"></i><?php echo htmlentities($result->SeatingCapacity);?> seats</li>
        <li><i class="fa fa-calendar" aria-hidden="true"></i><?php echo htmlentities($result->ModelYear);?> model</li>
        <li><i class="fa fa-car" aria-hidden="true"></i><?php echo htmlentities($result->FuelType);?></li>
      </ul>
      <a href="vehical-details.php?vhid=<?php echo htmlentities($result->id);?>" class="btn">
        View Details <span class="angle_arrow"><i class="fa fa-angle-right" aria-hidden="true"></i></span>
      </a>
    </div>
  </div>
<?php }} else { echo "<p>No results found.</p>"; } ?>
</div>
      
      <!-- Side-Bar -->
      <aside class="col-md-3 col-md-pull-9">
        <div class="sidebar_widget">
          <div class="widget_heading">
            <h5><i class="fa fa-filter" aria-hidden="true"></i> Find Your Equipment </h5>
          </div>
          <div class="sidebar_filter">
            <form method="get">
              <div class="form-group select">
                <select name="type" class="form-control">
                  <option value="">Select Type</option>
                  <?php 
                  $sql = "SELECT * FROM tbltypes";
                  $query = $dbh->prepare($sql);
                  $query->execute();
                  $types = $query->fetchAll(PDO::FETCH_OBJ);
                  foreach($types as $row) { ?>  
                    <option value="<?php echo htmlentities($row->id);?>" 
                      <?php if($type==$row->id) echo "selected"; ?>>
                      <?php echo htmlentities($row->BrandName);?>
                    </option>
                  <?php } ?>
                </select>
              </div>

              <div class="form-group select">
                <select name="fuel" class="form-control">
                  <option value="">Select Fuel Type</option>
                  <option value="None" <?php if($fuel=="None") echo "selected";?>>None</option>
                  <option value="Petrol" <?php if($fuel=="Petrol") echo "selected";?>>Petrol</option>
                  <option value="Diesel" <?php if($fuel=="Diesel") echo "selected";?>>Diesel</option>
                  <option value="CNG" <?php if($fuel=="CNG") echo "selected";?>>CNG</option>
                  <option value="Electric" <?php if($fuel=="Electric") echo "selected";?>>Electric</option>
                </select>
              </div>

              <div class="form-group">
                <input type="text" name="searchdata" class="form-control" placeholder="Enter keyword..." value="<?php echo htmlentities($searchdata);?>">
              </div>

              <div class="form-group">
                <button type="submit" class="btn btn-block">
                  <i class="fa fa-search" aria-hidden="true"></i> Search Equipment
                </button>
              </div>
            </form>
          </div>
        </div>

        <div class="sidebar_widget">
          <div class="widget_heading">
            <h5><i class="fa fa-car" aria-hidden="true"></i> Recently Listed Equipments</h5>
          </div>
          <div class="recent_addedcars">
            <ul>
<?php 
$sql = "SELECT tblequipments.*,tbltypes.BrandName,tbltypes.id as bid  
        FROM tblequipments 
        JOIN tbltypes ON tbltypes.id=tblequipments.VehiclesBrand 
        ORDER BY id DESC LIMIT 4";
$query = $dbh->prepare($sql);
$query->execute();
$recent=$query->fetchAll(PDO::FETCH_OBJ);
foreach($recent as $result) { ?>
  <li class="gray-bg">
    <div class="recent_post_img">
      <a href="vehical-details.php?vhid=<?php echo htmlentities($result->id);?>">
        <img src="admin/img/vehicleimages/<?php echo htmlentities($result->Vimage1);?>" alt="image">
      </a>
    </div>
    <div class="recent_post_title">
      <a href="vehical-details.php?vhid=<?php echo htmlentities($result->id);?>">
        <?php echo htmlentities($result->BrandName);?> , <?php echo htmlentities($result->VehiclesTitle);?>
      </a>
      <p class="widget_price">$<?php echo htmlentities($result->PricePerDay);?> Per Day</p>
    </div>
  </li>
<?php } ?>
            </ul>
          </div>
        </div>
      </aside>
      <!--/Side-Bar--> 
    </div>
  </div>
</section>

<!--Footer -->
<?php include('includes/footer.php');?>
<!-- /Footer--> 

<!--Back to top-->
<div id="back-top" class="back-top"> 
  <a href="#top"><i class="fa fa-angle-up" aria-hidden="true"></i></a> 
</div>

<!--Login/Register/Forgot-->
<?php include('includes/login.php');?>
<?php include('includes/registration.php');?>
<?php include('includes/forgotpassword.php');?>

<!-- Scripts --> 
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script> 
<script src="assets/js/interface.js"></script> 
<script src="assets/switcher/js/switcher.js"></script>
<script src="assets/js/bootstrap-slider.min.js"></script> 
<script src="assets/js/slick.min.js"></script> 
<script src="assets/js/owl.carousel.min.js"></script>

</body>
</html>
